#!/usr/bin/env bash
# =============================================================
#  LES VIEUX MURS — montage de la vidéo de haut de page
#  Étalonnage aligné sur la charte : vert #1A3224 / sable #D7C6A7
# =============================================================
set -e
SRC="${SRC:-./rushes}"
WORK="${WORK:-./edit}"
mkdir -p "$WORK"

# --- étalonnage "LVM" : noirs relevés vers le vert, hautes lumières vers le sable
GRADE="eq=contrast=1.08:saturation=0.78:gamma=0.98,\
colorbalance=rs=-0.045:gs=0.035:bs=-0.010:rm=0.020:gm=0.005:bm=-0.030:rh=0.048:gh=0.020:bh=-0.058,\
curves=all='0/0.028 0.25/0.24 0.5/0.5 0.75/0.78 1/0.975',\
vignette=angle=PI/5:mode=forward"

NORM="fps=25,scale=1920:1080:force_original_aspect_ratio=increase,crop=1920:1080,setsar=1,format=yuv420p"

shot () {  # $1 fichier  $2 in  $3 durée  $4 sortie
  ffmpeg -v error -ss "$2" -t "$3" -i "$SRC/$1" -an \
    -vf "$NORM,$GRADE" -c:v libx264 -crf 15 -preset medium -pix_fmt yuv420p \
    "$WORK/$4" -y
}

echo "→ Plan 1 · la table que l'on dresse"
shot "255364_Waiter_Wine_Glasses_Fine_Dining_Table_Setting_By_LACOFILMS_Artlist_HD.mp4" 3.4 5.2 s1.mp4
echo "→ Plan 2 · le geste du chef"
shot "36006_Flower_placed_on_scallops_extreme_closeup_By_Omri_Ohana_Artlist_HD.mp4"      0.6 5.2 s2.mp4
echo "→ Plan 3 · l'assiette, à table"
shot "65055_Fine_Nightlife_Foodporn_Date_By_Jakub_Klawikowski_Artlist_HD.mp4"            3.6 5.2 s3.mp4
echo "→ Plan 4 · les convives s'installent"
shot "357657_Date_Restaurant_Table_Woman_By_Hans_Peter_Schepp_Artlist_HD.mp4"            5.0 5.2 s4.mp4
echo "→ Plan 5 · la salle, le service"
shot "494556_Ordering_Waiter_Dining_Guests_Sitting_By_Stockbusters_Artlist_HD.mp4"       7.6 5.2 s5.mp4

# --- enchaînement en fondus (0,9 s)
echo "→ Enchaînements"
ffmpeg -v error -i "$WORK/s1.mp4" -i "$WORK/s2.mp4" -i "$WORK/s3.mp4" -i "$WORK/s4.mp4" -i "$WORK/s5.mp4" \
 -filter_complex "\
 [0][1]xfade=transition=fade:duration=0.9:offset=4.3[a];\
 [a][2]xfade=transition=fade:duration=0.9:offset=8.6[b];\
 [b][3]xfade=transition=fade:duration=0.9:offset=12.9[c];\
 [c][4]xfade=transition=fade:duration=0.9:offset=17.2[out]" \
 -map "[out]" -an -c:v libx264 -crf 15 -preset medium -pix_fmt yuv420p "$WORK/seq.mp4" -y

D=$(ffprobe -v error -show_entries format=duration -of csv=p=0 "$WORK/seq.mp4")
echo "→ Séquence : ${D}s — bouclage"

# --- bouclage sans raccord + encodage desktop, en une passe
#     A = seq[T..D] ; H = seq[0..T] ; le résultat démarre et finit sur seq[T]
T=0.9
OFF=$(python3 -c "print(round(($D - $T) - $T, 3))")
OUT="${OUT:-./assets/video}"
mkdir -p "$OUT"

ffmpeg -v error -i "$WORK/seq.mp4" -filter_complex "\
 [0]split[x][y];\
 [x]trim=start=$T,setpts=PTS-STARTPTS[A];\
 [y]trim=start=0:end=$T,setpts=PTS-STARTPTS[H];\
 [A][H]xfade=transition=fade:duration=$T:offset=$OFF[out]" \
 -map "[out]" -an -c:v libx264 -crf 25 -preset fast -profile:v high \
 -movflags +faststart -pix_fmt yuv420p "$OUT/lvm-hero-1080.mp4" -y

echo "→ Version mobile + image d'attente"
ffmpeg -v error -i "$OUT/lvm-hero-1080.mp4" -an -vf "scale=1280:720" \
  -c:v libx264 -crf 27 -preset fast -movflags +faststart -pix_fmt yuv420p \
  "$OUT/lvm-hero-720.mp4" -y
ffmpeg -v error -ss 1.5 -i "$OUT/lvm-hero-1080.mp4" -frames:v 1 -q:v 4 \
  "./assets/img/lvm-hero-poster.jpg" -y

echo "OK"
